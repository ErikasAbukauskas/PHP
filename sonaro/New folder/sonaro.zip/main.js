var a = 5;
console.log(a);


$(function() {

    $(".alert").fadeIn(2000).delay(3000).fadeOut(3000);
    
});